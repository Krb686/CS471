#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "process.h"


void demoteProcess(processP process){



}
