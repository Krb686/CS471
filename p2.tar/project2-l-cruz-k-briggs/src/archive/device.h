#include "process.h"


typedef struct device {
  int id;
  processP *head;
} Device;
